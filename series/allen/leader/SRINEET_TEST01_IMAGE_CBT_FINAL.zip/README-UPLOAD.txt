SRINEET TEST 01 — IMAGE BASED CBT

Exact GitHub structure:

SRINEET/
└── tests/
    └── series-01/
        ├── test-01.html
        └── assets/
            └── test01/
                ├── q001.webp
                ├── q002.webp
                ├── ...
                └── q180.webp

Upload BOTH the HTML file and the complete assets/test01 folder.

The HTML uses relative paths only and is GitHub Pages compatible.

The question image is cropped directly from the original Test 01 PDF, so mathematical symbols, roots, fractions, superscripts, subscripts, vectors, diagrams, tables and original formatting are preserved.

The four OPTION buttons below each image are the actual CBT answer controls.
